#pragma once
#include <string>

enum Degree {SECURITY,NETWORKING,SOFTWARE}; //three types of degree

static const std::string degreeStrings[] = { "SECURITY","NETWORKING","SOFTWARE" };